Este é o seu pacote de dados Discord!

Dentro, você encontrará alguns arquivos JSON (JavaScript Object Notation)
dos dados que usamos para te fornecer o serviço do Discord. Escolhemos este formato para facilitar
processar. Além disso, os arquivos foram organizados em grupos lógicos para que você
entenda e trabalhe com facilidade (pelo menos, é o que esperamos)!

Você deve ver as seguintes pastas no seu pacote de dados (embora algumas possam estar faltando
se você não tiver dados desse tipo):

- Conta: Inclui o seu avatar e algumas informações adicionais da conta
- Atividade: Contém quatro pastas (Analytics, Modeling, Reporting, Trust & Safety) com informações
sobre as ações que você realizou no Discord (observação: você não terá as pastas Analytics ou Modeling
no seu pacote de dados caso você tenha optado por não participar dessas atividades)
- Atividades: Contém pastas com informações sobre as atividades nas quais você participou
no Discord, assim como quaisquer dados e preferências do usuário relacionados a atividades
- Anúncios: Contém informações sobre anúncios com os quais você interagiu no Discord e características que usamos para veicular anúncios para você
- Mensagens: Inclui pastas para cada canal em que você enviou mensagens, além de algumas informações
sobre esses canais (observação: mensagens excluídas manualmente não são armazenadas no Discord e, portanto, não serão
inclusas no seu pacote de dados)
- Servidores: Contém pastas para cada servidor do qual você era membro no momento da sua solicitação de dados.
- Programas: Contém todas as informações fornecidas de qualquer aplicação caso você já tenha se inscrito anteriormente
no Programa de Parceria, Programa HypeSquad ou Programa de Servidor Verificado

Para mais informações, é só ler nosso artigo detalhado de ajuda na URL abaixo:

https://support.discord.com/hc/articles/360004957991

Abraços,
Equipe Discord
